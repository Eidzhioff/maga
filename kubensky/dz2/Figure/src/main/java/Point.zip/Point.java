public record Point(double x, double y) {
}
