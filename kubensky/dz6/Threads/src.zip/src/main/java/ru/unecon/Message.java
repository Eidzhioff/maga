package ru.unecon;

public record Message(int info) {}